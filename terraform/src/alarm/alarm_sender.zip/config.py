EMAIL_CONFIG = {
    "Source": 'mike.mo.jianxin@gmail.com',
    "Destination": {
        "ToAddresses": [
            'mike.mo.jianxin@gmail.com',
        ]
    },
    "Message": {
        "Subject": {
            "Data": 'Test Email',
        },
        "Body": {
            "Text": {
                "Data": 'Test Email Body',
            }
        }
    }
}
